import networkx as nx
import pandas as pd
import numpy as np
import math
import scipy.io
import time
import random
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import os
import pkg_resources
import csv


pd.options.mode.chained_assignment = None
global_model_name = None

#Identify frequency table column to sample
def get_ind(siz, x):
    k = np.cumprod([1] + siz[:-1])
    #print(k)
    ndx = np.dot(k, (np.array(x) - 1)) + 1
    return ndx

#Sample from frequency table selected column
def get_random(weights):
    #print(weights)
    r = np.random.rand()
    s = np.cumsum(weights)
    sthres = s[-1] * r
    x = s >= sthres
    index = np.argmax(x)
    #print(f"Randon Val: {r}, Idx selected: {index}")
    return index

#Add columns for transition distribution
def prepare_evidence_dataframe(X):
    # Add columns for Acceleration1, Vertical Rate1 y Turn Rate1 con valores 0
    X['Acceleration1'] = 0
    X['VRate1'] = 0
    X['TRate1'] = 0
    return X

# Convert discrete sampled values back to continuous form
def revert_discretization(binEdges, data_val):
    binStart = binEdges[data_val]
    binEnd = binEdges[data_val + 1]
    if binStart <= 0 and binEnd >= 0:
        return 0
    else:
        return binStart + (binEnd - binStart) * np.random.rand()
    


def simulation_new(IN_INIT_1, IN_C_1, IN_DYN_1, IN_R):
    dt = 0.1  # Time step [s]
    K = 1     # Integration gain
    g = 32.2  # Acceleration of gravity [ft/s^2]
    MAX_PHI = 75 * np.pi / 180
    MAX_PHI_DOT = 0.524
    NUM_AC = 1 

    initial_AC1 = IN_INIT_1
    controls_AC1 = IN_C_1
    dynamics_AC1 = IN_DYN_1
    runtime_s = IN_R

    breakflag = 0  
    renc_ft = 1000000  
    henc_ft = 1000000  
    minsimtime = 0

    NUM_INIT = 8  
    NUM_DYN = 6   

    v_ftps_min = dynamics_AC1[0]
    v_ftps_max = dynamics_AC1[1]
    dh_ftps_min = dynamics_AC1[2]
    dh_ftps_max = dynamics_AC1[3]
    qmax = dynamics_AC1[4]
    rmax = dynamics_AC1[5]
    
    # Initialize states for the aircraft
    x = np.array(initial_AC1) 
    
    # Determine number of time steps
    nvalues = int(runtime_s / dt + 1)

    bufout = np.full((nvalues, NUM_AC * 8), np.nan) 

    currt = 0

    bufout[0, 0:8] = [currt, x[1], x[2], x[3], x[0], x[6], x[5], x[4]]

    val = 1
    
    # Loop through each time step
    for i in range(1, nvalues):
        currt = i * dt  

        # Determine current command index
        cmd_i = np.where(controls_AC1[:, 0] == currt)[0]
        if cmd_i.size == 0:
            cmd_i = val
        else:
            val = cmd_i[0]
        
        if isinstance(cmd_i, np.ndarray):
            cmd_i=cmd_i.item()
        
        # Run dynamics for Aircraft
        x = integrateAircraftDynamics(x, controls_AC1, dynamics_AC1, cmd_i)

        bufout[i, 0:8] = [currt, x[1], x[2], x[3], x[0], x[6], x[5], x[4]]

    # Format outputs
    for ac in range(NUM_AC):
        results_ac = {
            'time': bufout[:, 0],
            'north_ft': bufout[:, 1 + (ac - 1) * 8],
            'east_ft': bufout[:, 1 + 1 + (ac - 1) * 8],
            'up_ft': bufout[:, 2 + 1 + (ac - 1) * 8],
            'speed_ftps': bufout[:, 3 + 1 + (ac - 1) * 8],
            'phi_rad': bufout[:, 4 + 1 + (ac - 1) * 8],
            'theta_rad': bufout[:, 5 + 1 + (ac - 1) * 8],
            'psi_rad': bufout[:, 6 + 1 + (ac - 1) * 8],
        }

    return results_ac
   # return bufout

def integrateAircraftDynamics(x, controls, dynamics, cmd_i):
  
    dt = 0.1  # Time step [s]
    K = 1     # Integration gain
    g = 32.2  # Gravity [ft/s^2]
    MAX_PHI = 75 * np.pi / 180 # Maximum bank angle [rad]
    MAX_PHI_DOT = 0.524 # Maximum roll rate [rad/s]
    
    # Extract dynamics parameters
    v_ftps_min = dynamics[0]  #Min velocity [ft/s]
    v_ftps_max = dynamics[1]  #Max velocity [ft/s]
    dh_ftps_min = dynamics[2] #Min vertical rate [ft/s]
    dh_ftps_max = dynamics[3] #Max vertical rate [ft/s]
    qmax = dynamics[4]        #Max pitch rate [rad/s]
    rmax = dynamics[5]        #Max yaw rate [rad/s]

    # Extract control commands
    acmd = controls[cmd_i, 1]    # Commanded acceleration [ft/s^2]
    dpsicmd = controls[cmd_i, 3] # Commanded change in heading [rad/s]
    dhcmd = controls[cmd_i, 2]   #Commanded vertical rate [ft/s]
    
    # Saturate vertical rate command within allowable limits
    dhcmd = max(min(dh_ftps_max, dhcmd), dh_ftps_min)  

    # Trigonometric values
    s_theta = np.sin(x[5]) #Pitch
    c_theta = np.cos(x[5])
    t_theta = np.tan(x[5])
    s_phi = np.sin(x[6])   #Bank
    c_phi = np.cos(x[6])
    s_psi = np.sin(x[4])   #Yaw
    c_psi = np.cos(x[4])

    # Current vertical speed and desired vertical acceleration
    hd = x[0] * s_theta
    hddcmd = 1 / dt * (dhcmd - hd)

    #Compute and saturate the pitch rate (q)
    q = 1 / (max(x[0], 1) * c_phi) * (hddcmd / c_theta + g * c_theta * s_phi * s_phi - acmd * t_theta)
    q = min(max(q, -qmax), qmax)

    # Compute and saturate the yaw rate (r)
    r = g * s_phi * c_theta / max(x[0], 1)
    r = min(max(r, -rmax), rmax)

    # Maximum allowable bank angle (phimax)
    hdd_cmd_phi = min(hddcmd, max(x[0], 1) * qmax * c_phi * c_theta)

    sqrt_arg = (max(x[0], 1))**2 * (qmax)**2 - 4 * g * acmd * s_theta + 4 * g * hdd_cmd_phi + 4 * (g)**2 * (c_theta)**2
    if sqrt_arg < 0:
        phi_max_2 = 10000
    else:
        cphi1 = (-max(x[0], 1) * qmax + np.sqrt(sqrt_arg)) / (2 * g * c_theta)

        if abs(cphi1) < 1:
            phi_max_2 = np.arccos(cphi1) * 0.98 
        else:
            phi_max_2 = 0  

    phimax = min(MAX_PHI, phi_max_2)

    # Compute and saturate the roll rate (p)  
    phi_cmd0 = np.arctan(dpsicmd * x[0] / g)
    psidot_if_no_change = (q * s_phi + r * c_phi) / c_theta
    dpsidot = dpsicmd - psidot_if_no_change
    #p = 20 * dpsidot
    p=0 * (phi_cmd0 - x[6]) + 20 * dpsidot + 0.0 * 0

    # Limit max rollrate
    if p > MAX_PHI_DOT:
        p = MAX_PHI_DOT
    elif p < -MAX_PHI_DOT:
        p = -MAX_PHI_DOT

    # Limit max bank angle
    if x[6] + p * dt > phimax:
        p = (phimax - x[6]) / dt
    elif x[6] + p * dt < -phimax:
        p = (-phimax - x[6]) / dt

    # Compute angular rates for roll, pitch, and yaw
    phidot = p + q * s_phi * t_theta + r * c_phi * t_theta
    thetadot = q * c_phi - r * s_phi
    psidot = q * s_phi / c_theta + r * c_phi / c_theta

    # Compute position rates (North, East, and vertical)
    Ndot = x[0] * c_theta * c_psi
    Edot = x[0] * c_theta * s_psi
    hdot = x[0] * s_theta
    

    # Backwards Euler integration of the states 
    x[0] = x[0] + acmd * dt * K
    x[1] = x[1] + Ndot * dt * K
    x[2] = x[2] + Edot * dt * K
    x[3] = x[3] + hdot * dt * K
    x[6] = x[6] + phidot * dt * K
    x[5] = x[5] + thetadot * dt * K
    x[4] = x[4] + psidot * dt * K

    # Saturate velocity within allowable limits
    if x[0] < v_ftps_min:
        x[0] = v_ftps_min
    if x[0] >= v_ftps_max:
        x[0] = v_ftps_max - 0.000001

    return x

def get_limits(N_initial, boundaries,isRotorcraft,Labels):
    #Calculate dynamic limits based on cutpoints
    idx_L=Labels.index('Altitude')
    idx_V = Labels.index('Speed')
    idx_DH = Labels.index('VRate')
    
    min_alt_ft = np.min(boundaries[idx_L])
    max_alt_ft = np.max(boundaries[idx_L])
    #print(f"idx_V={idx_V}, idx_DH={idx_DH}")
    v_initial = np.sum(N_initial[idx_V,0], axis=1)
    dh_initial = np.sum(N_initial[idx_DH,0], axis=1)
    #print(f"v_initial={v_initial}, dh_initial={dh_initial}")
    
    prct_low = 1
    prct_high = 99

    prob_V = 100*(v_initial/np.sum(v_initial, axis=0))
    #print(f"sum(v_initial,axis=0)=,prob_V ={prob_V}")
    cs_V = np.cumsum(prob_V)
    #print(f"cs_V={cs_V}")
    k_min_V = np.argmax(cs_V >= prct_low)
    k_max_V = np.argmax(cs_V >= prct_high)
    #print(f"k_min_V={k_min_V}, k_max_V={k_max_V}")

    min_speed_ft_s = boundaries[idx_V][0,k_min_V + 1] * 1.68780972222222  # v: KTAS -> ft/s
    max_speed_ft_s = boundaries[idx_V][0,k_max_V + 1] * 1.68780972222222  # v: KTAS -> ft/s
    #print(f"min_speed_ft_s={min_speed_ft_s}, max_speed_ft_s={max_speed_ft_s}")

    if isRotorcraft and max_speed_ft_s > 304:
        max_speed_ft_s = 304
    if not isRotorcraft and min_speed_ft_s < 30:
        min_speed_ft_s = 30

    prob_DH = 100 * (dh_initial / np.sum(dh_initial,axis=0))
    cs_DH = np.cumsum(prob_DH)
    k_min_DH = np.argmax(cs_DH >= prct_low)
    k_max_DH = np.argmax(cs_DH >= prct_high)
    #print(f"k_min_DH={k_min_DH}, k_max_DH={k_max_DH}")

    max_vertrate_ft_s = max(abs(boundaries[idx_DH][0,k_min_DH+1])/60,abs(boundaries[idx_DH][0,k_max_DH+1])/ 60)
    #print(f"max_vertrate_ft_s={max_vertrate_ft_s}")
    if np.isnan(max_vertrate_ft_s):
        max_vertrate_ft_s = 0

    dynamiclimits = {
        'minVel_ft_s': min_speed_ft_s,
        'maxVel_ft_s': max_speed_ft_s,
        'maxVertRate_ft_s': max_vertrate_ft_s
    }
    return min_alt_ft, max_alt_ft, dynamiclimits


def get_track_data(Initial_org, data, Cut_Points, Order_Cutpoints, resample, sample_time,idx_Ac,idx_TR):
    
    #Select appropiate labels
    if len(Initial_org.keys())==6:
        rearrange_In = ['Airspace', 'Altitude', 'Speed', 'Acceleration', 'VRate', 'TRate']
        inc=2
    else:
        rearrange_In = ['WTC','Airspace', 'Altitude', 'Speed', 'Acceleration', 'VRate', 'TRate']
        inc=3
            
        
    Initial_rev = np.zeros(len(Initial_org.keys()))
    
    # Revert Discretization Initial
    for i in range(len(Initial_org.keys())):
        edges = Cut_Points[Order_Cutpoints[i], 1].flatten()
        edges=edges.astype(float)
        if i == idx_Ac or i == idx_TR:
            if any(edge > 100 for edge in edges):
                edges = edges / 100
                Cut_Points[Order_Cutpoints[i], 1] = edges
        if np.all(np.diff(edges) == 1):
            Initial_rev[i] = np.array(Initial_org[rearrange_In[i]]).item()
        else:
            Initial_rev[i] = revert_discretization(edges, np.array(Initial_org[rearrange_In[i]]).item()-1)
        #print(f"edges={edges}")
            
    #print(f"Print Initial{Initial_rev}")       

    #Revert Discretization Transition
    data = np.array(data)
    data_org = data
    data_org = np.column_stack((np.arange(sample_time), data_org))
    X_old = data_org[0, 1:4]
    data_resample = data_org.copy()
    data_resample=np.array(data_resample, dtype=float)
    data_resample[0, 1:4] = Initial_rev[-3:]
    to_delete = []
    #print(f"data resample:{data_resample}")

    #Perform resampling
    for i in range(1, len(data_resample)):
        sample_again = np.where(np.random.rand(*resample.shape) < resample)[0] + 1
        if sample_again.size > 0:
            if not np.array_equal(X_old, data_resample[i, 1:4]):
                sample_again = np.unique(np.concatenate((sample_again, np.where(X_old != data_resample[i, 1:4])[0] + 1)))
            X_old = data_resample[i, 1:4].copy()
            data_resample[i, 1:4] = data_resample[i-1, 1:4].copy()
            for j in sample_again:
                edges = Cut_Points[Order_Cutpoints[j+inc], 1].flatten()
                data_resample[i, j] = revert_discretization(edges, int(X_old[j-1])-1)
        else:
            if not np.array_equal(X_old, data_resample[i, 1:4]):
                sample_again = np.where(X_old != data_resample[i, 1:4])[0] + 1
                X_old = data_resample[i, 1:4].copy()
                data_resample[i, 1:4] = data_resample[i-1, 1:4].copy()
                for j in sample_again:
                    edges = Cut_Points[Order_Cutpoints[j+inc], 1].flatten()
                    data_resample[i, j] = revert_discretization(edges, int(X_old[j-1])-1)
            else:
                data_resample[i, 1:4] = data_resample[i-1, 1:4].copy()
                to_delete.append(i)

    #print(f"data resample:{data_resample}") 
    control = np.delete(data_resample, to_delete, axis=0)
    #print('control: {control}')
    
    control[:, 2] = control[:, 2] / 60  # Convert fpm a fps
    control[:, 3] = control[:, 3] * (math.pi / 180)  # Convert deg/s to rad/s
    control[:, 1] = control[:, 1] * 1.68780972222222  # Convert kts/s to ft/s²

    #print(f'control: {control}')

    #Unit conversions
    h_ft = Initial_rev[rearrange_In.index('Altitude')]; 
    v_ft_s = Initial_rev[rearrange_In.index('Speed')] * 1.68780972222222;   #KTAS -> ft/s 
    dv_ft_ss = Initial_rev[rearrange_In.index('Acceleration')] * 1.68780972222222;   #kt/s -> ft/s^2
    dh_ft_s = Initial_rev[rearrange_In.index('VRate')] / 60;  #ft/min -> ft/s
    dpsi_rad_s = (math.pi / 180)*(Initial_rev[rearrange_In.index('TRate')]);  #deg/s -> rad/s

    #Calculate heading, pitch and bank angles
    heading_rad = 0
    if abs(v_ft_s) < 1e-9:
        pitch_rad =0
    else:
        pitch_rad = math.asin(dh_ft_s / v_ft_s);

    bank_rad = math.atan(v_ft_s * dpsi_rad_s / 32.2);
    
    #Initial conditions for track 
    n_ft=0
    e_ft=0
    ic = [v_ft_s, n_ft, e_ft, h_ft, heading_rad, pitch_rad, bank_rad, dv_ft_ss];
    dyn = [1.7, max(Cut_Points[np.where(Cut_Points[:,0] == 'Speed')[0][0] , 1].flatten())* 1.68780972222222, min(Cut_Points[np.where(Cut_Points[:,0] == 'Vertical Rate')[0][0] , 1].flatten())/60, max(Cut_Points[np.where(Cut_Points[:,0] == 'Vertical Rate')[0][0] , 1].flatten())/60, (math.pi / 180)*3, 1000000];

    #print(f"ic={ic}")
    #print(f"control={control}")
    #print(f"dyn={dyn}")
    
    #Obtain track
    RESULTS = simulation_new(ic, control, dyn, sample_time)
    return RESULTS


def generate_valid_results(data_model,track_num, sample_time,seed):
    
    #Extract data from MAtlab file
    G_matrix_initial= data_model['DAG_Initial']
    G_initial = nx.from_numpy_array(G_matrix_initial, create_using=nx.DiGraph)
    order_initial = list(nx.topological_sort(G_initial))

    G_matrix_transition= data_model['DAG_Transition']
    G_transition = nx.from_numpy_array(G_matrix_transition, create_using=nx.DiGraph)
    order_transition = list(nx.topological_sort(G_transition))
    
    N_initial=data_model['N_initial']
    N_transition = data_model['N_transition']
    
    dynamic_variables=order_transition[-3:]
    dynamic_variables.sort()

    #Select appropiate labels
    if len(order_initial) == 6:
        Labels = ['Airspace', 'Altitude', 'Speed', 'Acceleration', 'VRate', 'TRate']
    else:
        Labels = ['WTC', 'Airspace', 'Altitude', 'Speed', 'Acceleration', 'VRate', 'TRate']
    
   #Get Cut points and resample rate files
    Cut_Points = data_model['Cut_Points']
    resample_rate = data_model['resample_rate']
    resample = resample_rate[-3:, 0]
    
    #Added for old files
    airspace_exists = False
    for item in Cut_Points:
        if item[0][0] == 'Airspace':
            airspace_exists = True
            #print("'Airspace' está presente.")
            break

    # If Airspace is not present, add it
    if not airspace_exists:
        airspace_entry = [np.array(['Airspace'], dtype='<U8'), np.array([[1., 2., 3., 4., 5., 6., 7.]])]

        Cut_Points = Cut_Points.tolist()
        Cut_Points.append(airspace_entry)
        my_array = np.empty((len(Cut_Points), 2), dtype=object)

        for i, item in enumerate(Cut_Points):
            my_array[i, 0] = item[0]
            my_array[i, 1] = item[1]
        Cut_Points=my_array
    
    #Select appropiate labels for cutpoints
    if  len(order_initial)==6:
        if Cut_Points[0,0][0] == 'Aceleration':
            order_Cutpoints_labels = ['Airspace', 'Altitude', 'Speed', 'Aceleration', 'Vertical Rate', 'Turn Rate']
            idx_Ac = order_Cutpoints_labels.index('Aceleration')
        else:
            order_Cutpoints_labels = ['Airspace', 'Altitude', 'Speed', 'Acceleration', 'Vertical Rate', 'Turn Rate']
            idx_Ac = order_Cutpoints_labels.index('Acceleration')
    else:
        order_Cutpoints_labels = ['WTC','Airspace', 'Altitude', 'Speed', 'Acceleration', 'Vertical Rate', 'Turn Rate']
        idx_Ac = order_Cutpoints_labels.index('Acceleration')
    
    # Get index for cutpoints to adjust
    Order_Cutpoints = [np.where(Cut_Points[:,0] == label)[0][0] for label in order_Cutpoints_labels]
    idx_TR = order_Cutpoints_labels.index('Turn Rate')
    boundaries = Cut_Points[Order_Cutpoints, 1]
    isRotorcraft = False
   
    
    #Obtain dynamic limits
    min_alt_ft, max_alt_ft,dynamiclimits= get_limits(N_initial, boundaries,isRotorcraft,Labels)
    #print(f"min alt={min_alt_ft}, max alt={max_alt_ft}, min speed: {dynamiclimits['minVel_ft_s']}, min speed: {dynamiclimits['maxVel_ft_s']},max Vrate {dynamiclimits['maxVertRate_ft_s']}")
    
    dynvar_depend = np.any(G_matrix_transition[np.ix_(dynamic_variables, dynamic_variables)])
    
    valid_results = []
    invalid_results = []
    X_Initial_total=[]
    inX_Initial_total=[]
    all_results_by_X=[]
    inall_results_by_X=[]
    total_results = 0
    wrong_tracks=0
    
    if (seed==True):
        seed_val=1

    while total_results < track_num:
        #state = np.random.get_state()
        #print(seed)
        #np.random.seed(seed)
        if (seed==True):
            np.random.seed(seed_val)
            seed_val+=1
        else:
            np.random.seed(None)
                
        S = np.zeros(len(order_initial), dtype=int)
        r = [arr[0].shape[0] for arr in N_initial]
        r = np.array(r)

        #Perform sampling initial 
        for i in order_initial:
            parents = G_matrix_initial[:, i]
            j = 0
            if np.any(parents):
                j = get_ind(r[parents == 1].tolist(), S[parents == 1].tolist())
            S[i] = get_random(N_initial[i][0][:, j-1]) + 1

        X_initial = pd.DataFrame([S], columns=Labels)
        
        #Perform sampling transition
        r_t = [arr[0].shape[0] for arr in N_transition]
        r_t[:-3] = r
        r_t = np.array(r_t)
        X_initial_copy = X_initial.copy()
        X = prepare_evidence_dataframe(X_initial_copy)
        all_results = []
        X = X.to_numpy().reshape(-1)

        if dynvar_depend:
            for _ in range(sample_time):
                for i in order_transition[-3:]:
                    parents = G_matrix_transition[:, i]
                    j = 0
                    if np.any(parents):
                        j = get_ind(r_t[parents == 1].tolist(), X[parents == 1].tolist())
                    X[i] = get_random(N_transition[i][0][:, j-1]) + 1
                    X[i-3] = X[i]
                all_results.append(X[-3:].copy())
                X[-3:] = 0
        else:
            j = np.full(len(order_transition), np.nan)
            s = [None] * len(order_transition)
            sthres = np.zeros(((sample_time, len(order_transition))))

            for i in order_transition[-3:]:
                parents = G_matrix_transition[:, i]
                if np.any(parents):
                    j[i] = get_ind(r_t[parents == 1].tolist(),  X[parents == 1].tolist())
                else:
                    j[i] = 1

                s[i] = np.cumsum(N_transition[i][0][:, int(j[i])-1])
                sthres[:, i] = s[i][-1] * np.random.rand(sample_time)

            for t in range(0, sample_time):
                for i in order_transition[-3:]:
                    X[i] = np.searchsorted(s[i], sthres[t, i]) + 1
                    X[i-3] = X[i]
                all_results.append(X[-3:].copy())
                X[-3:] = 0


        #Obtain track based on sampling
        result = get_track_data(X_initial, all_results, Cut_Points, Order_Cutpoints, resample, sample_time, idx_Ac, idx_TR)

        #Set dynamic limits
        dh = np.gradient(result['up_ft'], result['time'])
        results_dh_ft_s = abs(dh)
        is_violate_L = np.any((result['up_ft'] < min_alt_ft) | (result['up_ft'] > max_alt_ft+500))
        is_violate_V = np.any((result['speed_ftps'] < dynamiclimits['minVel_ft_s']) | (result['speed_ftps'] > dynamiclimits['maxVel_ft_s']))
        is_violate_DH = np.any(results_dh_ft_s > dynamiclimits['maxVertRate_ft_s'])
        
        #np.random.set_state(state)
        #seed=seed+1
        
        #Check if track is valid
        if not (is_violate_L or is_violate_V or is_violate_DH):
            valid_results.append(result)
            X_Initial_total.append(S)
            all_results_by_X.append(all_results)
            total_results += 1
            #print(f"Resultado válido #{total_results} guardado.")
        else:
            #print(f"Altitude={is_violate_L}, Speed={ is_violate_V}, VRate={is_violate_DH} ")
            invalid_results.append(result)
            inX_Initial_total.append(S)
            inall_results_by_X.append(all_results)
            wrong_tracks+=1
                
    #print({f"Wrong tracks={wrong_tracks}"})
    #Convert output to dataframe
    X_Initial_total = pd.DataFrame(X_Initial_total, columns=Labels)
    inX_Initial_total = pd.DataFrame(inX_Initial_total, columns=Labels)

    #return valid_results, X_Initial_total, all_results_by_X, invalid_results, inX_Initial_total, inall_results_by_X
    #return valid_results
    return valid_results, X_Initial_total, all_results_by_X


def gen_track(filename, sample_time, track_num,seed=False):
    global global_model_name
    start_time = time.time()
    try:

        if not os.path.isfile(filename): 
            package_mat_dir = pkg_resources.resource_filename(__name__, 'data') 
            full_filename = os.path.join(package_mat_dir, filename) 
            if not os.path.isfile(full_filename): 
                print(f"The file {filename} was not found in the current directory or in the package.") 
                return None
            else: filename = full_filename 
        
        global_model_name = os.path.splitext(os.path.basename(filename))[0]
        #Load matlab data
        data_model = scipy.io.loadmat(filename, mat_dtype=True)
        Results, X, T=generate_valid_results(data_model,track_num, sample_time,seed)
        #Results, X, T, IRES, Xi, iT=generate_valid_results(data_model,track_num, sample_time)
        end_time = time.time()  # End time
        total_time = end_time - start_time
        print(f"Total time taken: {total_time} seconds")
        #return Results, X, T
        return Results
    except FileNotFoundError:
        print(f"The file {filename} was not found.")
        return None
    except Exception as e:
        print(f"An error occurred while loading the file: {e}")
        return None


def get_unique_filename(base_name, extension):
    i = 0
    new_name = f"{base_name}{extension}"
    while os.path.exists(new_name):
        i += 1
        new_name = f"{base_name}_{i}{extension}"
    return new_name


def generate_plot(RESULTS, title=None):
    global global_model_name
    if title is None:
        title = global_model_name.replace('_', ' ') if global_model_name else "Track Generation Tool"
    
    fig = plt.figure()
    ax = fig.add_subplot(111, projection='3d')

    for i in range(len(RESULTS)):
        north_ft = RESULTS[i]['north_ft']
        east_ft = RESULTS[i]['east_ft']
        up_ft = RESULTS[i]['up_ft']
        ax.plot3D(north_ft, east_ft, up_ft, label=f'Track {i+1}')
        ax.plot3D(north_ft, east_ft, up_ft)

    ax.set_xlabel('North (ft)')
    ax.set_ylabel('East (ft)')
    ax.set_zlabel('Up (ft)')

    ax.set_title(title)

    ax.legend()

    plt.show()

    
def save_as_Matlab(RESULTS, name=None):
    global global_model_name
    if name is None:
        name = global_model_name if global_model_name else "result_model"
    filename = get_unique_filename(f"{name}_Result", '.mat')
    scipy.io.savemat(filename, {'Tracks': RESULTS})
    print(f"Saved MATLAB file: {filename}")


def get_mat_files():
    mat_dir = pkg_resources.resource_filename(__name__, 'data') 
    return [f for f in os.listdir(mat_dir) if f.endswith('.mat')]


def save_to_csv(results, filename_base=None):
    global global_model_name
    if not results:
        print("The results list is empty. No file will be saved.")
        return
    
    if filename_base is None:
        filename_base = global_model_name if global_model_name else "result_model"
    
    # Define max number of rows per file
    MAX_ROWS = 1000000

    # Extract field names
    fieldnames = ['Aircraft_ID'] + list(results[0].keys())

    row_count = 0
    
    filename = get_unique_filename(f"{filename_base}_Result", '.csv')
    file = open(filename, mode='w', newline='')
    writer = csv.writer(file)
    
    # Write header
    writer.writerow(fieldnames)
    print(f"Writing to {filename}...")

    for aircraft_id, result in enumerate(results, start=1):
        num_rows = len(result['time'])

        if row_count + num_rows > MAX_ROWS:
            if file:
                file.close()  
            
            filename = get_unique_filename(f"{filename_base}_Result", '.csv')
            file = open(filename, mode='w', newline='')
            writer = csv.writer(file)

            # Write header
            writer.writerow(fieldnames)

            print(f"Writing to {filename}...")
            row_count = 0  # Reset row count for the new file

    
        for i in range(num_rows):
            row = [aircraft_id]  
            row.extend(result[key][i] for key in result.keys())  
            writer.writerow(row)
        
        row_count += num_rows 

    if file:
        file.close()

    print("Data successfully saved.")

